import firebase from "firebase/app";

import "firebase/firestore";
import "firebase/auth";

var firebaseConfig = {
  apiKey: "AIzaSyAMAjmyxkYBVvshDBueGZazIMPF0xiFPL8",
  authDomain: "ssn-app-web.firebaseapp.com",
  databaseURL: "https://ssn-app-web.firebaseio.com",
  projectId: "ssn-app-web",
  storageBucket: "ssn-app-web.appspot.com",
  messagingSenderId: "143839020003",
  appId: "1:143839020003:web:25ec6495b2f43762"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.firestore().settings({ timestampsInSnapshots: true });

export default firebase;
