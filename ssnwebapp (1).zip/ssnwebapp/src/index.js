import React from "react";
import ReactDOM from "react-dom";

import App from "./App";
import * as serviceWorker from "./serviceWorker";

// Put any other imports below so that CSS from your
// components takes precedence over default styles.
import "./index.css";

import { createStore, applyMiddleware, compose } from "redux"; //applyMiddleware used  needed to add thunk or other store enhancers
import rootReducer from "./store/reducers/rootReducer";
import { Provider } from "react-redux"; //binds react with redux
import thunk from "redux-thunk"; //thunk is sed to make async calls before calling reducers i.e custom actions

//getFirebase and getFirestore provide methods to make api calls
import { reduxFirestore, getFirestore } from "redux-firestore";
import { reactReduxFirebase, getFirebase } from "react-redux-firebase";

import fbConfig from "./config/fbConfig";

//compose is used to combine multiple store enhancers like thunk(which is a middleware) and firebase config functions (reduxFirestore etc)
//reduxFirestore and reactReduxFirebase take out firebase app config as arg , this is used to connect db to redux store
//the getFirebase and getFirestore are only methods and do not have any config info

const store = createStore(
  rootReducer,
  compose(
    applyMiddleware(thunk.withExtraArgument({ getFirebase, getFirestore })),
    reduxFirestore(fbConfig),
    reactReduxFirebase(fbConfig)
  )
);

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById("root")
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
