import React, { Component } from 'react';

class Sidebar extends Component {
  state = {  }
  render() { 
    return ( 
      <React.Fragment>
        
      </React.Fragment>
     );
  }
}
 
export default Sidebar;