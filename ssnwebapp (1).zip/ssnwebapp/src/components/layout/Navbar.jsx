import React, { Component } from "react";
import { Link } from "react-router-dom";

class Navbar extends Component {
  state = {};
  render() {
    return (
      <React.Fragment>
        <nav className="navbar navbar-expand-md bg-dark navbar-dark navbar-right">
          <Link to="/" className="brand-logo">
            SSN
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#collapsibleNavbar"
          >
            <span className="navbar-toggler-icon" />
          </button>
          <div className="collapse navbar-collapse" id="collapsibleNavbar">
            <ul className="navbar-nav ">
              <li className="nav-item">
                <Link to="/" className="brand-logo nav-link">
                  Posts
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/post/new" className="brand-logo nav-link">
                  New Post
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/" className="brand-logo nav-link">
                  Sign In
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/" className="brand-logo nav-link">
                  Sign Up
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      </React.Fragment>
    );
  }
}

export default Navbar;
