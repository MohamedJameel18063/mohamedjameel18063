import React, { Component } from "react";

import PostList from "../posts/PostList";
import Notifications from "../dashboard/Notifications";
import { connect } from "react-redux"; //returns a higher order component taking a normal component as argument
import { firestoreConnect } from "react-redux-firebase";
//  firestoreConnect higher order component like connect which tells firebaseReducer which collection to keep synccing while using dashboard component

import { compose } from "redux";

class Dashboard extends Component {
  state = {};
  render() {
    console.log(this.props);
    const { posts } = this.props;
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-8">
            <h1 className="text-content  text-primary ml-4">Posts</h1>
            <PostList posts={posts} />
          </div>
          <div className="col-md-4">
            <Notifications />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateProps = state => {
  //takes state of store
  console.log(state);
  return {
    posts: state.firestore.ordered.post_cse // mapping the props of this component to the post in the state returned from rootreducer
  };
};

//  firestoreConnect() takes in array of objects telling whichall collections to connect to
export default compose(
  connect(mapStateProps),
  firestoreConnect([{ collection: "post_cse" }])
)(Dashboard);
