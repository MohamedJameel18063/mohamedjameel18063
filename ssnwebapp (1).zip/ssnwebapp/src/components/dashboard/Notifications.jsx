import React, { Component } from "react";

class Notifications extends Component {
  state = {};
  render() {
    return (
      <div className="container">
        <h3 className="text-success " style={{ marginTop: "50px" }}>
          Notifcations
        </h3>
        <div className="card">
          <div className="card-header" />
          <div className="card-body">
            <p>Recent Activity</p>
            <p>Upcoming Events</p>
          </div>
        </div>
      </div>
    );
  }
}

export default Notifications;
