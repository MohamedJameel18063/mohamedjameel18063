import React, { Component } from "react";
import { Link } from "react-router-dom";

import PostSummary from "./PostSummary";

class PostList extends Component {
  state = {};
  render() {
    const { posts } = this.props;
    return (
      <div className="container">
        {posts && //done to prevent errors when posts array is null
          posts.map(post => {
            return (
              <Link
                to={"/post/" + post.id}
                style={{ textDecoration: "none", color: "black" }}
                className="postItem"
              >
                <PostSummary post={post} key={post.id} />
              </Link>
            );
          })}
      </div>
    );
    
    

  }
}


export default PostList;
