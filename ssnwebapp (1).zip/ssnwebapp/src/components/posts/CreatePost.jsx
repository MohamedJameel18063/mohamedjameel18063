import React, { Component } from "react";
import { createPost } from "../../store/actions/postActions";
import { connect } from "react-redux";

class CreatPost extends Component {
  state = {
    title: "",
    description: ""
  };

  handleOnChange = e => {
    this.setState({
      [e.target.id]: e.target.value
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    console.log(this.state);
    this.props.createPost(this.state);
    this.props.history.push("/");
  };
  render() {
    return (
      <div className="container">
        <h1 className="text-primary">New Post</h1>
        <form>
          <div className="form-group">
            <label htmlFor="title">Post Title</label>
            <input
              type="text"
              className="form-control"
              id="title"
              aria-describedby=""
              onChange={this.handleOnChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="description">Post Content</label>
            <textarea
              name=""
              className="form-control"
              id="description"
              cols="30"
              rows="10"
              onChange={this.handleOnChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="file">Attach Files</label>
            <input
              type="file"
              className="form-control"
              id="file"
              aria-describedby=""
              onChange={this.handleOnChange}
            />
          </div>
          <button
            type="submit"
            className="btn btn-primary"
            onClick={this.handleSubmit}
          >
            Create Post
          </button>
        </form>
      </div>
    );
  }
}
const mapDispatchToProps = dispatch => {
  return {
    createPost: post => dispatch(createPost(post)) //when createPost is called it calls the dispatch whichgoes to action where async calls are made with the post
  };
};

export default connect(
  null,
  mapDispatchToProps
)(CreatPost); //mapStateTOProps not there so use null
