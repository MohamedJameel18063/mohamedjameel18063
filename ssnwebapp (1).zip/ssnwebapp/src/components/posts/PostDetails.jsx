import React, { Component } from "react";

class PostDetails extends Component {
  state = {};
  render() {
    return (
      <div className="container">
        <div class="card bg-light mb-3 ">
          <h5 class="card-header  ">
            Post Title- {this.props.match.params.id}
          </h5>
          <div class="card-body">
            <h5 class="card-title">Post Subject</h5>
            <p class="card-text">
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Saepe,
              atque deleniti nostrum cumque pariatur qui veniam vero deserunt
              magni similique quia iusto nemo iste ab cum dolorem sapiente aut
              aperiam?
            </p>
          </div>
        </div>
      </div>
    );
  }
}

export default PostDetails;
