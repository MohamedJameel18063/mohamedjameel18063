import React, { Component } from "react";

class PostSummary extends Component {
  state = {};
  render() {
    const { post } = this.props;
    const date = post.time.toDate().toLocaleDateString();

    return (
      <div className="container ">
        <div className="card bg-light mb-3">
          {/* <img class="card-img-top" src="" alt="Card image cap" /> */}
          <div className="card-header">
            <h5 className="card-title">
              <span>
                <img src={post.author_image_url} alt="" class="avatar mr-3" />
              </span>
              {"    "}
              {post.title}
            </h5>
            <span className="text-right ml-5 text-muted">{post.position}</span>
          </div>
          <div className="card-body pt-4">
            {/* <h5 className="card-title">Subject:</h5> */}
            <p className="card-text">{post.description.slice(0, 150)} ...</p>
            <p className="text-right text-muted">
              <small class="muted text-right">{date}</small>
            </p>
          </div>
        </div>
      </div>
    );
  }
}

export default PostSummary;
