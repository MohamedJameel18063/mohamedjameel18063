export const createPost = post => {
  return (dispatch, getState, { getFirebase, getFirestore }) => {
    //getState has current store details
    //thunk allows us tho return a function

    //make async calls
    const firestore = getFirestore();
    firestore
      .collection("post_cse")
      .add({
        ...post,
        author: "Dr. Chitra Babu",
        author_image_url:
          "https://firebasestorage.googleapis.com/v0/b/ssn-app-web.appspot.com/o/faculty%2Fprofile%2FF0001.jfif?alt=media&token=c2a376e1-8bd5-4df9-827f-7dff8cbe50e2",
        position: "Head of department",
        year: 2016,
        time: new Date()
      })
      .then(() => {
        dispatch({ type: "CREATE_POST", post: post }); //this json inside is the action obect which can be used by the root reducer
      })
      .catch(err => {
        dispatch({ type: "CREATE_POST_ERROR", err: err });
      });
  };
};
