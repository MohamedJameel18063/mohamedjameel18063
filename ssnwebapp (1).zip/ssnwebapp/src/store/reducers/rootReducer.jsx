import authReducer from "./authReducer";
import postReducer from "./postReducer";
import { combineReducers } from "redux";
import { firestoreReducer } from "redux-firestore";
//syncing firestore data with the store in the background (it knows about data from fbconfig which is sent to rootreducer)
const rootReducer = combineReducers({
  auth: authReducer,
  post: postReducer,
  firestore: firestoreReducer
});
//only the data needed by current component will be synced automatically by fireStoreReducer

export default rootReducer;
